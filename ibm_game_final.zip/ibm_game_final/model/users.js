var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var usersSchema=new Schema({
    name:{type:String},
    handle: {type:String},
    email:{type:String},
    password:{type:String},
    phone:{type:String,max:20},
    friends:[],
    date_of_creation:{type:Number,required:true,default:new Date().getTime()},
    date_of_modification:{type:Number,required:true,default:new Date().getTime()}
});
module.exports=mongoose.model('users',usersSchema);