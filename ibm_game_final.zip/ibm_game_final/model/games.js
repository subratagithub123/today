var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var onlineSchema=new Schema({
    handle:{type:String},
    connection_id: {type:String},
    date_of_creation:{type:Number,required:true,default:new Date().getTime()},
    date_of_modification:{type:Number,required:true,default:new Date().getTime()}
});
module.exports=mongoose.model('onlines',onlineSchema);