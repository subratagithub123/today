var mongoose=require('mongoose');
var Schema=mongoose.Schema;

var messageSchema=new Schema({
    _user:{type:Schema.Types.ObjectId,ref:'users',required:true},
    message:{type:String},
    sender: {type:String},
    reciever:{type:String},
    date_of_creation:{type:Number,required:true,default:new Date().getTime()},
    date_of_modification:{type:Number,required:true,default:new Date().getTime()}
});
module.exports=mongoose.model('messages',messageSchema);