//var $=jQuery;
//$.noConflict();
//$(".chat_head").click(function(){ alert("++"); })  in console dubugger
//$(document).ready(function()
//{
//    $('div').on('click', function()
//    {
//        alert('clicked!');
//    });
//});
function toggleHead(){
    $('.chat_body').slideToggle('slow');
    
}
function toggleMsg(){
    $('.msg_wrap').slideToggle('slow');
    
}
function closeMsg(){
    $('.msg_box').hide();
    
}
function toggleOnline(){
    $('.chat_body2').slideToggle('slow');
    
}

function chat_message(){
    $('msg_input').keypress(
    function(e){
        if (e.keyCode == 13) {
            e.preventDefault();
            var msg = $(this).val();
			$(this).val('');
			if(msg!='')
			$('<div class="msg_b">'+msg+'</div>').insertBefore('.msg_push');
			$('.msg_body').scrollTop($('.msg_body')[0].scrollHeight);
        }
    });
}
//$(document).ready(function(){
//        $('.chat_head').on('click',function(){
//            alert('sdfsdsdf');
//        $('.chat_body').slideToggle('slow');
//	});
//	$('.msg_head').click(function(){
//		$('.msg_wrap').slideToggle('slow');
//	});
//	
//	$('.close').click(function(){
//		$('.msg_box').hide();
//	});
//	
//	$('.user').click(function(){
//
//		$('.msg_wrap').show();
//		$('.msg_box').show();
//	});
//	
//	$('textarea').keypress(
//    function(e){
//        if (e.keyCode == 13) {
//            e.preventDefault();
//            var msg = $(this).val();
//			$(this).val('');
//			if(msg!='')
//			$('<div class="msg_b">'+msg+'</div>').insertBefore('.msg_push');
//			$('.msg_body').scrollTop($('.msg_body')[0].scrollHeight);
//        }
//    });
//	
//});