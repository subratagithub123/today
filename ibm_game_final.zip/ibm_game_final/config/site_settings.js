var SiteSetting = require('../models/site_settings');
global.SITE_SETTINGS={};
var result=SiteSetting.find({},function(err,result){
    for(var i=0;i<result.length;i++){
        SITE_SETTINGS[result[i]['slug'].toUpperCase()]=result[i]['setting_value'];
    }
});


