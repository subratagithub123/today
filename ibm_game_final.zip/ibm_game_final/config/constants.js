var fs = require("fs");
module.exports={
    'enviroment':process.env.CHAT_APP_ENV,
    'server_port':8080,
    'chat_server_socket_port':8080,
    'auth_server':process.env.CHAT_AUTHSERVER_URL,
    'base_url':process.env.CHAT_BASE_URL,
    'api_base_url':this.base_url+'api_v1',
    'api_route_path':'/api_v1/',
    'database':'mongodb://localhost/chat',
    'secret_key':process.env.CHAT_SECRETE_KEY,
    'issuer':process.env.CHAT_ISSUER,
    'audience':process.env.CHAT_AUDIENCE,
    'algorithms':process.env.CHAT_ALGORITHMS,
    'expireToken':false,
    'profile_image_path':'../NodeJS/public/uploads/profile_images',
    'group_image_path':'../NodeJS/public/uploads/group_images',
    'contact_book_image_path':'../NodeJS/public/uploads/contact_book_images',
    'profile_image_public_link':process.env.CHAT_BASE_URL+'uploads/profile_images/',
    'group_image_public_link':process.env.CHAT_BASE_URL+'uploads/group_images/',
    'contact_book_image_public_link':process.env.CHAT_BASE_URL+'uploads/contact_book_images/'
//    'getPrivateKey':function(){
//        return fs.readFileSync('./keys/private.pem');
//    },
//    'getPublicKey':function(){
//        return fs.readFileSync('./keys/public.pem');
//    },
//    'getDomainSSLKey':function(){
//        return fs.readFileSync('./ssl/private.key');
//    },
//    'getDomainSSLCertificate':function(){
//        return fs.readFileSync('./ssl/url.crt');
//    },
//    'getDomainSSLKey':function(){
//        return fs.readFileSync('./ssl/private.key');
//    },
//    'getDomainSSLCertificate':function(){
//        return fs.readFileSync('./ssl/testurl.crt');
//    },
//    'getDomainRootChainCertificate':function(){
//        return temp=[
//            fs.readFileSync('./ssl/ca_bundle.crt')
//        ];
//    }
};
